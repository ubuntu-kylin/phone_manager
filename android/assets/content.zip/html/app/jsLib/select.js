// JavaScript Document
function load()
{
	

	var i;
	for(i=2;i<13;i++){
		$("#content"+i).hide();			
		}
		
}

function changecontent(num){
	var i;
	for(i=1;i<13;i++){
		$("#content"+i).hide();	
		
		}
		$("#content"+num).fadeIn();
		
	
	}
	
	